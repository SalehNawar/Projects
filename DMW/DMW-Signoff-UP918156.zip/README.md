# distributed master/worker server and worker setup
This is a simple master-worker distributed software with server worker gcloud setup.
## Installation
log in to your server and make sure that startDMW.sh, startClient.sh and delete scripts are in your home directory

To run the server, use the command below, but replace the the NUM with a number between 1 and 5:
```
./startDMW.sh NUM
```
