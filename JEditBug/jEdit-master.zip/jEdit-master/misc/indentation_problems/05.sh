if a; then
  f

# In line 2 one is to type "find".
# "fi" is a keyword defined in unindentThisLine property and
# "i" is an electric key.
# It should be indented as it is initially:

if a; then
  find
